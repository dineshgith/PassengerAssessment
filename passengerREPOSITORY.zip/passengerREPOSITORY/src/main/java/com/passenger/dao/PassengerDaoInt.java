package com.passenger.dao;

import com.passenger.entity.Passenger;

public interface PassengerDaoInt {

	long save(Passenger passenger);

	Passenger get(long id);

	void update(long id, Passenger passenger);

	void remove(long id);

}
