package com.passenger.service;

import com.passenger.entity.Passenger;

public interface PassengerServiceInt {
	long save(Passenger passenger);

	Passenger get(long id);

	void update(long id, Passenger passenger);

	void remove(long id);

}
