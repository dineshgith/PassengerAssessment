package com.passenger.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.passenger.entity.Passenger;
import com.passenger.service.PassengerServiceInt;

@RestController
public class Controller {

	@Autowired
	private PassengerServiceInt passengerServiceInt;

	@PostMapping("/passenger")
	public ResponseEntity<String> save(@RequestBody Passenger passenger) {
		long id = passengerServiceInt.save(passenger);
		return ResponseEntity.ok().body("new passenger is saved" + id);
	}

	@GetMapping("/passenger/{id}")
	public ResponseEntity<Passenger> get(@PathVariable("id") long id) {
		Passenger passenger = passengerServiceInt.get(id);
		return ResponseEntity.ok().body(passenger);
	}

	@PutMapping("/passenger/{id}")
	public ResponseEntity<?> update(@PathVariable("id") long id, @RequestBody Passenger passenger) {
		passengerServiceInt.update(id, passenger);
		return ResponseEntity.ok().body("passenger details Updated successfully");
	}

	@DeleteMapping("/passenger/{id}")
	public ResponseEntity<?> remove(@PathVariable("id") long id) {
		passengerServiceInt.remove(id);
		return ResponseEntity.ok().body("Deleted successfully");

	}

}
