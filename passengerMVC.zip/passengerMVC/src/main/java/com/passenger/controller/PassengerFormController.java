package com.passenger.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.passenger.entity.Passenger;
import com.passenger.service.PassengerServiceInt;

public class PassengerFormController {
	@Autowired
	private PassengerServiceInt passengerServiceInt;

	@RequestMapping(value = "passenger")
	public ModelAndView user() {
		ModelAndView mv = new ModelAndView("passenger", "pgr", new Passenger());
		return mv;
	}

	@RequestMapping(value = "addPassenger", method = RequestMethod.POST)
	public String addPassenger(@ModelAttribute("passenger") @Validated Passenger passenger, BindingResult result,
			ModelMap model, HttpServletRequest request) {
		if (!result.hasErrors()) {
			passengerServiceInt.save(passenger);
		}
		return "passenger";
	}

	@RequestMapping(value = "passengerById")
	public String getPassengerById(ModelMap model, @RequestParam("pid") long pid) {
		Passenger passenger = passengerServiceInt.get(pid);
		model.addAttribute(passenger);
		return "passenger";
	}

	@RequestMapping(value = "updatePassenger", method = RequestMethod.POST)
	public String updatePassenger(@ModelAttribute("passenger") @Validated Passenger passenger, @RequestParam("id") long id, 
			BindingResult result, ModelMap model, HttpServletRequest request) {
		if (!result.hasErrors()) {
			passengerServiceInt.update(id, passenger);
		}
		return "passenger";
	}

	@RequestMapping(value = "deletePassenger")
	public String deletePassenger(ModelMap model, HttpServletRequest request) {
		int pid = Integer.parseInt(request.getParameter("pid"));
		passengerServiceInt.remove(pid);
		return "passenger";
	}
	
}
