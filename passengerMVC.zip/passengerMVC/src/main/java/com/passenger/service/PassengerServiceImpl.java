package com.passenger.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.passenger.dao.PassengerDaoInt;
import com.passenger.entity.Passenger;

@Service
public class PassengerServiceImpl implements PassengerServiceInt {

	@Autowired
	private PassengerDaoInt passangerDaoInt;

	public long save(Passenger passenger) {
		// TODO Auto-generated method stub
		return passangerDaoInt.save(passenger);
	}

	public Passenger get(long id) {
		// TODO Auto-generated method stub
		return passangerDaoInt.get(id);
	}

	public void update(long id, Passenger passenger) {
		// TODO Auto-generated method stub
		passangerDaoInt.update(id, passenger);

	}

	public void remove(long id) {
		// TODO Auto-generated method stub
		passangerDaoInt.remove(id);
	}

}
