package com.passenger.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.passenger.entity.Passenger;

@Repository
@Transactional
public class PassengerDaoImpl implements PassengerDaoInt {

	@Autowired
	private SessionFactory sessionfactory;

	public long save(Passenger passenger) {
		// TODO Auto-generated method stub
		sessionfactory.getCurrentSession().save(passenger);
		return passenger.getId();
	}

	public Passenger get(long id) {
		// TODO Auto-generated method stub
		return sessionfactory.getCurrentSession().get(Passenger.class, id);
	}

	public void update(long id, Passenger passenger) {
		// TODO Auto-generated method stub
		Session session = sessionfactory.getCurrentSession();
		Passenger psngr = session.byId(Passenger.class).load(id);
		psngr.setPassword(passenger.getPassword());
		psngr.setFirstName(passenger.getFirstName());
		psngr.setLastName(passenger.getLastName());
		psngr.setAddress(passenger.getAddress());
		psngr.setTelNumber(passenger.getTelNumber());
		psngr.setEmail(passenger.getEmail());
		session.flush();

	}

	public void remove(long id) {
		// TODO Auto-generated method stub
		Session session = sessionfactory.getCurrentSession();
		Passenger psngr = session.byId(Passenger.class).load(id);
		session.delete(psngr);

	}

}
